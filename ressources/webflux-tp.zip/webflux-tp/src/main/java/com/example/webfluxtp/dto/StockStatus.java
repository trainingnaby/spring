package com.example.webfluxtp.dto;

public record StockStatus(String orderId, boolean reserved, String warehouse) { }
