package com.example.webfluxtp.dto;

public record DeliveryStatus(String orderId, String carrier, String status, int etaMinutes) { }
