package com.example.webfluxtp.simulator;

import com.example.webfluxtp.dto.DeliveryStatus;
import com.example.webfluxtp.dto.PaymentStatus;
import com.example.webfluxtp.dto.StockStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.time.Duration;

@RestController
@RequestMapping("/mock")
public class ExternalServicesSimulatorController {

    @GetMapping("/payments/{orderId}")
    Mono<PaymentStatus> payment(@PathVariable String orderId) {
        return Mono.just(new PaymentStatus(orderId, "PAID", 129.90))
                .delayElement(Duration.ofMillis(900));
    }

    @GetMapping("/stocks/{orderId}")
    Mono<StockStatus> stock(@PathVariable String orderId) {
        return Mono.just(new StockStatus(orderId, true, "PARIS-NORD"))
                .delayElement(Duration.ofMillis(700));
    }

    @GetMapping("/deliveries/{orderId}")
    Mono<DeliveryStatus> delivery(@PathVariable String orderId) {
        return Mono.just(new DeliveryStatus(orderId, "Chronopost", "IN_TRANSIT", 45))
                .delayElement(Duration.ofMillis(1200));
    }
}
