package com.example.webfluxtp.service;

import com.example.webfluxtp.dto.DeliveryStatus;
import com.example.webfluxtp.dto.OrderEvent;
import com.example.webfluxtp.dto.OrderSummary;
import com.example.webfluxtp.dto.PaymentStatus;
import com.example.webfluxtp.dto.StockStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.time.Instant;
import java.util.List;

@Service
public class OrderAggregationService {

    private final WebClient webClient;

    public OrderAggregationService(WebClient webClient) {
        this.webClient = webClient;
    }

    public Mono<OrderSummary> getSummary(String orderId) {
        Mono<PaymentStatus> payment = webClient.get()
                .uri("/mock/payments/{orderId}", orderId)
                .retrieve()
                .bodyToMono(PaymentStatus.class);

        Mono<StockStatus> stock = webClient.get()
                .uri("/mock/stocks/{orderId}", orderId)
                .retrieve()
                .bodyToMono(StockStatus.class);

        Mono<DeliveryStatus> delivery = webClient.get()
                .uri("/mock/deliveries/{orderId}", orderId)
                .retrieve()
                .bodyToMono(DeliveryStatus.class)
                .timeout(Duration.ofSeconds(2));

        return Mono.zip(payment, stock, delivery)
                .map(tuple -> new OrderSummary(
                        orderId,
                        tuple.getT1(),
                        tuple.getT2(),
                        tuple.getT3(),
                        computeGlobalStatus(tuple.getT1(), tuple.getT2(), tuple.getT3()),
                        Instant.now()
                ));
    }

    public Flux<OrderEvent> streamEvents(String orderId) {
        List<String> steps = List.of(
                "Commande reçue",
                "Paiement validé",
                "Stock réservé",
                "Colis préparé",
                "Colis remis au transporteur",
                "Livraison en cours"
        );

        return Flux.interval(Duration.ZERO, Duration.ofSeconds(1))
                .take(steps.size())
                .map(index -> new OrderEvent(
                        orderId,
                        "ORDER_TRACKING",
                        steps.get(index.intValue()),
                        Instant.now()
                ));
    }

    private String computeGlobalStatus(PaymentStatus payment, StockStatus stock, DeliveryStatus delivery) {
        if (!"PAID".equals(payment.status())) {
            return "WAITING_PAYMENT";
        }
        if (!stock.reserved()) {
            return "WAITING_STOCK";
        }
        if ("IN_TRANSIT".equals(delivery.status())) {
            return "ON_THE_WAY";
        }
        return "READY";
    }
}
