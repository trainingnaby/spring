package com.example.webfluxtp.dto;

public record PaymentStatus(String orderId, String status, double amount) { }
