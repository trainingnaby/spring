package com.example.webfluxtp.controller;

import com.example.webfluxtp.dto.OrderEvent;
import com.example.webfluxtp.dto.OrderSummary;
import com.example.webfluxtp.service.OrderAggregationService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderAggregationService service;

    public OrderController(OrderAggregationService service) {
        this.service = service;
    }

    @GetMapping("/{orderId}/summary")
    Mono<OrderSummary> summary(@PathVariable String orderId) {
        return service.getSummary(orderId);
    }

    @GetMapping(value = "/{orderId}/events", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    Flux<OrderEvent> events(@PathVariable String orderId) {
        return service.streamEvents(orderId);
    }
}
