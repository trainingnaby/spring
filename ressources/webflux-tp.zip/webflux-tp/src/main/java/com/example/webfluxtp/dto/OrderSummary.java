package com.example.webfluxtp.dto;

import java.time.Instant;

public record OrderSummary(
        String orderId,
        PaymentStatus payment,
        StockStatus stock,
        DeliveryStatus delivery,
        String globalStatus,
        Instant generatedAt
) { }
