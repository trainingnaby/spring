package com.example.webfluxtp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebfluxTpApplication {
    public static void main(String[] args) {
        SpringApplication.run(WebfluxTpApplication.class, args);
    }
}
