package com.example.webfluxtp.dto;

import java.time.Instant;

public record OrderEvent(String orderId, String eventType, String message, Instant emittedAt) { }
