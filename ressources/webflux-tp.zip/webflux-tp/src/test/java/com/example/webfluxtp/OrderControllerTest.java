package com.example.webfluxtp;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.reactive.server.WebTestClient;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
class OrderControllerTest {


    @Autowired
    WebTestClient webTestClient;

    @Test
    void shouldReturnOrderSummary() {
        webTestClient.get()
                .uri("/api/orders/CMD-100/summary")
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.orderId").isEqualTo("CMD-100")
                .jsonPath("$.globalStatus").isEqualTo("ON_THE_WAY");
    }

    @Test
    void shouldStreamOrderEvents() {
        webTestClient.get()
                .uri("/api/orders/CMD-100/events")
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentTypeCompatibleWith("text/event-stream");
    }
}
