# TP Spring WebFlux - Agrégation réactive et streaming temps réel

## Objectif pédagogique

Découverte de la programmation déclarative et réactive avec Spring WebFlux.

Le cas métier est volontairement réaliste : une application de suivi de commande e-commerce doit construire une vue unique à partir de plusieurs services externes lents :

- service de paiement ;
- service de stock ;
- service de livraison ;
- flux temps réel d'événements de suivi.

C'est un domaine où WebFlux est plus adapté que Spring MVC lorsque l'application fait beaucoup d'appels réseau concurrents ou diffuse des événements sans bloquer un thread par requête.

## Pourquoi WebFlux plutôt que Spring MVC ici ?

Avec Spring MVC classique, chaque requête occupe généralement un thread pendant l'attente des réponses externes.

Dans ce TP, l'endpoint `/api/orders/{orderId}/summary` appelle trois faux services externes qui répondent lentement :

- paiement : environ 900 ms ;
- stock : environ 700 ms ;
- livraison : environ 1200 ms.

En impératif bloquant, si on appelle ces services l'un après l'autre, le temps total approche 2,8 secondes.

Avec WebFlux et `Mono.zip(...)`, les trois appels partent en parallèle et le temps total approche celui du plus lent, donc environ 1,2 seconde.

## Technologies utilisées

- Java 17
- Spring Boot 3.5.13
- Spring WebFlux
- Project Reactor : `Mono` et `Flux`
- WebClient non bloquant
- Server-Sent Events, aussi appelés SSE
- Maven

## Import dans Eclipse

1. Ouvrir Eclipse.
2. Menu `File` > `Import`.
3. Choisir `Maven` > `Existing Maven Projects`.
4. Sélectionner le dossier `webflux-tp`.
5. Cliquer sur `Finish`.
6. Attendre le téléchargement des dépendances Maven.
7. Lancer la classe :

```text
com.example.webfluxtp.WebfluxTpApplication
```

## Lancer le projet en ligne de commande

```bash
mvn spring-boot:run
```

Puis ouvrir :

```text
http://localhost:8080
```

## Endpoints disponibles

### Page de démonstration

```text
GET /
```

Ouvre une page HTML simple pour tester le résumé et le flux SSE.

### Résumé agrégé d'une commande

```text
GET /api/orders/CMD-100/summary
```

Exemple de réponse :

```json
{
  "orderId": "CMD-100",
  "payment": {
    "orderId": "CMD-100",
    "status": "PAID",
    "amount": 129.9
  },
  "stock": {
    "orderId": "CMD-100",
    "reserved": true,
    "warehouse": "PARIS-NORD"
  },
  "delivery": {
    "orderId": "CMD-100",
    "carrier": "Chronopost",
    "status": "IN_TRANSIT",
    "etaMinutes": 45
  },
  "globalStatus": "ON_THE_WAY"
}
```

### Flux d'événements temps réel

```text
GET /api/orders/CMD-100/events
Accept: text/event-stream
```

Avec curl :

```bash
curl -N http://localhost:8080/api/orders/CMD-100/events
```

Le serveur envoie progressivement des événements sans fermer immédiatement la connexion.

## Structure du projet

```text
src/main/java/com/example/webfluxtp
├── config
│   └── WebClientConfig.java
├── controller
│   └── OrderController.java
├── dto
│   ├── DeliveryStatus.java
│   ├── OrderEvent.java
│   ├── OrderSummary.java
│   ├── PaymentStatus.java
│   └── StockStatus.java
├── service
│   └── OrderAggregationService.java
├── simulator
│   └── ExternalServicesSimulatorController.java
└── WebfluxTpApplication.java
```

## Déroulé conseillé du TP

### Étape 1 - Comprendre `Mono`

Un `Mono<T>` représente une valeur future : zéro ou une valeur.

Dans le projet :

```java
Mono<PaymentStatus> payment = webClient.get()
        .uri("/mock/payments/{orderId}", orderId)
        .retrieve()
        .bodyToMono(PaymentStatus.class);
```

Point important : tant qu'on ne s'abonne pas à la chaîne réactive, rien n'est exécuté. Dans une application WebFlux, Spring s'abonne pour nous au moment de traiter la requête HTTP.

### Étape 2 - Comprendre `Flux`

Un `Flux<T>` représente une suite de valeurs : zéro, une ou plusieurs valeurs.

Dans le projet :

```java
return Flux.interval(Duration.ZERO, Duration.ofSeconds(1))
        .take(steps.size())
        .map(index -> new OrderEvent(...));
```

Ce flux est exposé en `text/event-stream` pour produire des Server-Sent Events.

### Étape 3 - Comprendre la composition déclarative

Au lieu d'écrire :

```java
PaymentStatus payment = callPayment();
StockStatus stock = callStock();
DeliveryStatus delivery = callDelivery();
return buildSummary(payment, stock, delivery);
```

on déclare un pipeline :

```java
return Mono.zip(payment, stock, delivery)
        .map(tuple -> new OrderSummary(...));
```

La logique décrit ce qu'on veut obtenir, pas comment bloquer le thread étape par étape.

### Étape 4 - Mesurer le gain

Appeler :

```bash
curl http://localhost:8080/api/orders/CMD-100/summary
```

Les trois services simulés ont des délais cumulés de 2,8 secondes, mais la réponse arrive en environ 1,2 seconde, car les appels sont parallélisés.

## Exercices

### Exercice 1 - Ajouter un service client

Créer un nouveau record :

```java
public record CustomerInfo(String orderId, String fullName, String email) { }
```

Ajouter dans `ExternalServicesSimulatorController` :

```java
@GetMapping("/customers/{orderId}")
Mono<CustomerInfo> customer(@PathVariable String orderId) {
    return Mono.just(new CustomerInfo(orderId, "Alice Martin", "alice@example.com"))
            .delayElement(Duration.ofMillis(600));
}
```

Puis modifier `OrderSummary` et `OrderAggregationService` pour inclure cette donnée.

### Exercice 2 - Gérer une erreur externe

Modifier le mock livraison pour provoquer une erreur sur une commande particulière :

```java
if ("ERROR".equals(orderId)) {
    return Mono.error(new RuntimeException("Service livraison indisponible"));
}
```

Puis utiliser :

```java
.onErrorReturn(new DeliveryStatus(orderId, "UNKNOWN", "UNAVAILABLE", -1))
```

Objectif : comprendre qu'en réactif, les erreurs sont aussi des signaux dans le flux.

### Exercice 3 - Ajouter un timeout

Le code contient déjà :

```java
.timeout(Duration.ofSeconds(2))
```

Réduire le timeout à 500 ms et d'observer le comportement.

### Exercice 4 - Comparer avec une version bloquante

Créer une méthode pédagogique qui simule des appels successifs avec `Thread.sleep(...)`, puis comparer le temps total avec la version `Mono.zip(...)`.

## Points d'attention à expliquer

### Ne pas appeler `block()` dans un contrôleur WebFlux

À éviter :

```java
PaymentStatus payment = paymentMono.block();
```

Cela casse l'intérêt de WebFlux, car on force le thread à attendre.

### WebFlux n'est pas automatiquement plus rapide

WebFlux est pertinent surtout pour :

- beaucoup d'I/O réseau ;
- appels API externes ;
- streaming ;
- backpressure ;
- connexions longues ;
- nombre élevé de requêtes concurrentes.

Pour une application CRUD simple avec JPA bloquant, Spring MVC reste souvent plus simple.

## Pourquoi ce cas d'usage est adapté à Webflux ?


> Parce que le serveur passe beaucoup de temps à attendre des réponses réseau. WebFlux permet de composer ces attentes sans bloquer un thread par appel, et permet aussi de diffuser des événements en streaming avec `Flux`.
