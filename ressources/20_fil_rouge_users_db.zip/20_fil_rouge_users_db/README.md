# TP 20 - Spring Security : utilisateurs stockés en base de données

Ce TP repart du corrigé précédent, qui contenait déjà :

- une application Spring Boot ;
- une interface Thymeleaf protégée par formulaire de login ;
- des endpoints REST protégés par JWT ;
- Spring Data JPA avec H2 ;
- les tests unitaires et d'intégration du TP précédent.

L'objectif de ce TP est de remplacer le référentiel d'utilisateurs **en mémoire** par un référentiel **persisté en base de données H2**.

Avant ce TP, les utilisateurs étaient déclarés dans `SecurityConfig` avec `InMemoryUserDetailsManager`.

Après ce TP, les utilisateurs sont chargés depuis la base via :

```java
DatabaseUserDetailsService implements UserDetailsService
```

Le formulaire de login et l'endpoint JWT utilisent donc le même référentiel utilisateur.

---

## Objectifs pédagogiques

Notions à connaitre :

- expliquer le rôle de `UserDetailsService` ;
- remplacer `InMemoryUserDetailsManager` par un service maison ;
- modéliser un utilisateur et ses rôles en JPA ;
- charger un utilisateur depuis la base pendant l'authentification ;
- comprendre le rôle du `PasswordEncoder` ;
- utiliser le même référentiel pour le login formulaire et pour le login JWT ;
- vérifier les utilisateurs dans la console H2.

---


## Comptes de test

| Login | Mot de passe | Rôles |
|---|---|---|
| `user` | `user` | `USER` |
| `admin` | `admin` | `USER`, `ADMIN` |

Ces utilisateurs sont insérés au démarrage dans `src/main/resources/data.sql`.

---

## URLs utiles

| Fonction | URL |
|---|---|
| Application front | `http://localhost:8080/ui/duplicatas` |
| Login | `http://localhost:8080/login` |
| Dashboard temps réel | `http://localhost:8080/ui/dashboard` |
| Swagger UI | `http://localhost:8080/swagger-ui.html` |
| Console H2 | `http://localhost:8080/h2-console` |
| Actuator health | `http://localhost:8080/actuator/health` |

---

## Accès à la console H2

Ouvrir :

```text
http://localhost:8080/h2-console
```

Utiliser les paramètres suivants :

```text
JDBC URL : jdbc:h2:mem:duplicatasdb
User     : sa
Password : laisser vide
```

Requêtes utiles :

```sql
select * from app_user;
select * from app_user_roles;
select * from duplicata;
```

---

# Partie 1 - Comprendre la limite du référentiel en mémoire

Dans les TPs précédents, la configuration ressemblait à ceci :

```java
@Bean
UserDetailsService userDetailsService(PasswordEncoder passwordEncoder) {
    UserDetails user = User.withUsername("user")
            .password(passwordEncoder.encode("user"))
            .roles("USER")
            .build();

    UserDetails admin = User.withUsername("admin")
            .password(passwordEncoder.encode("admin"))
            .roles("USER", "ADMIN")
            .build();

    return new InMemoryUserDetailsManager(user, admin);
}
```

C'est pratique pour apprendre Spring Security, mais ce n'est pas réaliste :

- les utilisateurs disparaissent au redémarrage ;
- on ne peut pas administrer les comptes en base ;
- on ne peut pas ajouter facilement des informations métier ;
- on ne montre pas comment Spring Security se branche sur une vraie source de données.

Dans ce TP, cette partie a été supprimée de `SecurityConfig`.

---

# Partie 2 - Modéliser les utilisateurs

## Entité `AppUser`

Fichier :

```text
src/main/java/com/formation/domain/security/AppUser.java
```

Elle contient :

```java
@Entity
@Table(name = "app_user")
public class AppUser {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String username;

    @Column(nullable = false)
    private String password;

    private boolean enabled = true;

    private String fullName;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "app_user_roles", joinColumns = @JoinColumn(name = "user_id"))
    @Enumerated(EnumType.STRING)
    @Column(name = "role")
    private Set<AppRole> roles = new HashSet<>();
}
```

Points importants :

- `username` est unique ;
- `password` contient le mot de passe encodé ou préfixé ;
- `enabled` permet de désactiver un compte ;
- les rôles sont stockés dans une table séparée `app_user_roles`.

---

## Enumération `AppRole`

Fichier :

```text
src/main/java/com/formation/domain/security/AppRole.java
```

```java
public enum AppRole {
    USER,
    ADMIN
}
```

En base, on stocke seulement :

```text
USER
ADMIN
```

Mais Spring Security attend des autorités de la forme :

```text
ROLE_USER
ROLE_ADMIN
```

La transformation est faite dans `DatabaseUserDetailsService`.

---

# Partie 3 - Créer le repository JPA

Fichier :

```text
src/main/java/com/formation/repository/security/AppUserRepository.java
```

```java
public interface AppUserRepository extends JpaRepository<AppUser, Long> {

    Optional<AppUser> findByUsernameIgnoreCase(String username);

    boolean existsByUsernameIgnoreCase(String username);
}
```

Ce repository utilise une requête dérivée Spring Data JPA.

La méthode importante pour Spring Security est :

```java
findByUsernameIgnoreCase(String username)
```

Elle permet de retrouver un utilisateur au moment de l'authentification.

---

# Partie 4 - Brancher Spring Security sur la base

Fichier :

```text
src/main/java/com/formation/security/DatabaseUserDetailsService.java
```

```java
@Service
public class DatabaseUserDetailsService implements UserDetailsService {

    private final AppUserRepository appUserRepository;

    public DatabaseUserDetailsService(AppUserRepository appUserRepository) {
        this.appUserRepository = appUserRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        AppUser appUser = appUserRepository.findByUsernameIgnoreCase(username)
                .orElseThrow(() -> new UsernameNotFoundException("Utilisateur introuvable : " + username));

        List<SimpleGrantedAuthority> authorities = appUser.getRoles().stream()
                .map(role -> new SimpleGrantedAuthority("ROLE_" + role.name()))
                .toList();

        return User.builder()
                .username(appUser.getUsername())
                .password(appUser.getPassword())
                .disabled(!appUser.isEnabled())
                .authorities(authorities)
                .build();
    }
}
```

Cette classe est le point clé du TP.

Spring Security ne sait pas directement lire notre table `app_user`. Il sait en revanche utiliser un bean `UserDetailsService`.

Notre classe joue donc le rôle d'adaptateur :

```text
Base de données -> AppUser -> UserDetails Spring Security
```

---

# Partie 5 - Nettoyer `SecurityConfig`

Dans `SecurityConfig`, on garde :

```java
@Bean
PasswordEncoder passwordEncoder() {
    return PasswordEncoderFactories.createDelegatingPasswordEncoder();
}
```

Mais on supprime le bean :

```java
InMemoryUserDetailsManager
```

Spring Boot détecte automatiquement notre bean :

```java
@Service
public class DatabaseUserDetailsService implements UserDetailsService
```

Ce service est alors utilisé par :

- le formulaire de login Spring Security ;
- l'endpoint REST `/api/auth/login` ;
- le filtre JWT, lorsqu'il recharge l'utilisateur depuis le token.

---

# Partie 6 - Initialiser les utilisateurs en base

Fichier :

```text
src/main/resources/data.sql
```

```sql
insert into app_user(id, username, password, enabled, full_name, created_at)
values (1, 'user', '{noop}user', true, 'Utilisateur consultation', current_timestamp);

insert into app_user(id, username, password, enabled, full_name, created_at)
values (2, 'admin', '{noop}admin', true, 'Administrateur formation', current_timestamp);

insert into app_user_roles(user_id, role) values (1, 'USER');
insert into app_user_roles(user_id, role) values (2, 'USER');
insert into app_user_roles(user_id, role) values (2, 'ADMIN');
```

Pour le TP, les mots de passe sont préfixés avec :

```text
{noop}
```

Cela signifie : pas d'encodage.

C'est volontairement simple pour garder le focus sur le branchement base de données.

En production, il faut utiliser BCrypt :

```text
{bcrypt}$2a$10$...
```

---

# Partie 7 - Tester la connexion formulaire

Démarrer l'application :

```bash
mvn spring-boot:run
```

Ouvrir :

```text
http://localhost:8080/login
```

Tester :

```text
user / user
```

Puis :

```text
admin / admin
```

Constat attendu :

- `user` peut consulter les duplicatas ;
- `user` ne peut pas créer ni supprimer ;
- `admin` peut consulter, créer et supprimer.

---

# Partie 8 - Tester l'authentification JWT avec les mêmes utilisateurs

Obtenir un token utilisateur :

```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"user","password":"user"}'
```

Obtenir un token administrateur :

```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin"}'
```

Appeler une ressource protégée :

```bash
curl http://localhost:8080/duplicatas \
  -H "Authorization: Bearer VOTRE_TOKEN"
```

Créer un duplicata avec le token admin :

```bash
curl -X POST http://localhost:8080/duplicatas_dto \
  -H "Authorization: Bearer VOTRE_TOKEN_ADMIN" \
  -H "Content-Type: application/json" \
  -d '{"user_id":"u1","montant":2500}'
```

Avec un token `user`, la création doit retourner `403 Forbidden`.

---

# Partie 9 - Exercices

## Exercice 1

Identifier dans le projet l'ancien mécanisme en mémoire et expliquer pourquoi il a été supprimé.

## Exercice 2

Créer l'entité `AppUser`.

## Exercice 3

Créer l'énumération `AppRole`.

## Exercice 4

Créer le repository `AppUserRepository`.

## Exercice 5

Créer `DatabaseUserDetailsService`.

## Exercice 6

Modifier `SecurityConfig` pour supprimer `InMemoryUserDetailsManager`.

## Exercice 7

Initialiser deux comptes dans `data.sql`.

## Exercice 8

Tester :

- login formulaire ;
- login JWT ;
- accès `USER` ;
- accès `ADMIN` ;
- refus `403` pour un utilisateur non administrateur.

---

# Variante possible : utiliser BCrypt

Pour aller plus loin, remplacez :

```sql
'{noop}admin'
```

par un hash BCrypt :

```sql
'{bcrypt}$2a$10$...'
```

Le bean suivant sait gérer plusieurs formats grâce au préfixe :

```java
PasswordEncoderFactories.createDelegatingPasswordEncoder()
```

Formats typiques :

```text
{noop}motdepasse
{bcrypt}hash_bcrypt
```

=> Spring Security ne compare jamais directement les mots de passe : il passe toujours par un `PasswordEncoder`.

---

# Fichiers importants du corrigé

```text
src/main/java/com/formation/domain/security/AppUser.java
src/main/java/com/formation/domain/security/AppRole.java
src/main/java/com/formation/repository/security/AppUserRepository.java
src/main/java/com/formation/security/DatabaseUserDetailsService.java
src/main/java/com/formation/config/SecurityConfig.java
src/main/resources/data.sql
```

---

# Import dans Eclipse

1. `File` > `Import`.
2. `Maven` > `Existing Maven Projects`.
3. Sélectionner le dossier du projet.
4. Cliquer sur `Finish`.
5. Clic droit sur le projet > `Maven` > `Update Project`.
6. Lancer `DuplicataImpotsApplication`.

---

# Commandes utiles

Lancer l'application :

```bash
mvn spring-boot:run
```

Lancer les tests :

```bash
mvn test
```

Créer un package :

```bash
mvn clean package
```
