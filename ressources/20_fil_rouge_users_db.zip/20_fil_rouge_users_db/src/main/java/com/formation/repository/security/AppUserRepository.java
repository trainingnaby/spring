package com.formation.repository.security;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.formation.domain.security.AppUser;

public interface AppUserRepository extends JpaRepository<AppUser, Long> {

    Optional<AppUser> findByUsernameIgnoreCase(String username);

    boolean existsByUsernameIgnoreCase(String username);
}
