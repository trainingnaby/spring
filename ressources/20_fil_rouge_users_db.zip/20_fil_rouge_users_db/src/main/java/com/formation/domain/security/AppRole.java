package com.formation.domain.security;

/**
 * Roles applicatifs stockes en base.
 *
 * Spring Security attend ensuite des autorites sous la forme ROLE_USER,
 * ROLE_ADMIN, etc. La conversion est faite dans DatabaseUserDetailsService.
 */
public enum AppRole {
    USER,
    ADMIN
}
