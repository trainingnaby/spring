
-- ==========================================================================
-- Utilisateurs applicatifs Spring Security
-- ==========================================================================
-- Les mots de passe sont volontairement simples pour le TP :
--   user / user
--   admin / admin
-- Le prefixe {noop} indique au PasswordEncoder pedagogique de ne pas chiffrer
-- le mot de passe. En production, utiliser {bcrypt} avec un hash BCrypt.
insert into app_user(id, username, password, enabled, full_name, created_at)
values (1, 'user', '{noop}user', true, 'Utilisateur consultation', current_timestamp);

insert into app_user(id, username, password, enabled, full_name, created_at)
values (2, 'admin', '{noop}admin', true, 'Administrateur formation', current_timestamp);

insert into app_user_roles(user_id, role) values (1, 'USER');
insert into app_user_roles(user_id, role) values (2, 'USER');
insert into app_user_roles(user_id, role) values (2, 'ADMIN');

insert into duplicata(id, user_id, montant, pdf_url, created_at)
values ('dup-demo-001', 'u1', 2500, 'https://cdn.prod.impots/pdfs/dummy.pdf', current_timestamp);

insert into duplicata(id, user_id, montant, pdf_url, created_at)
values ('dup-demo-002', 'u2', 4200, 'https://cdn.prod.impots/pdfs/dummy.pdf', current_timestamp);

insert into duplicata(id, user_id, montant, pdf_url, created_at)
values ('dup-demo-003', 'FR_123456789', 6100, 'https://cdn.prod.impots/pdfs/dummy.pdf', current_timestamp);
