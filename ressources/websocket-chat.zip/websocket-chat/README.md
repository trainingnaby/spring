# TP Spring Boot WebSocket : Chat en temps réel

## 1. Objectif pédagogique

Ce TP montre comment créer un chat temps réel avec :

- Spring Boot ;
- Spring WebSocket ;
- STOMP ;
- SockJS côté navigateur ;
- HTML, CSS et JavaScript vanilla.

À la fin du TP, les apprenants savent :

- expliquer la différence entre HTTP classique et WebSocket ;
- configurer un endpoint WebSocket avec Spring ;
- publier un message depuis le navigateur vers le serveur ;
- diffuser un message du serveur vers tous les clients connectés ;
- importer et exécuter un projet Spring Boot dans Eclipse.

Ce TP s'inspire de l'approche officielle Spring avec WebSocket + STOMP, où STOMP est utilisé comme sous-protocole de messagerie au-dessus de WebSocket.

---

## 2. Pré-requis

- Java 17 ou supérieur ;
- Eclipse IDE for Enterprise Java and Web Developers ;
- Maven intégré à Eclipse ou Maven installé localement ;
- Navigateur web récent.

Vérification Java :

```bash
java -version
```

---

## 3. Importer le projet dans Eclipse

1. Ouvrir Eclipse.
2. Aller dans `File > Import...`.
3. Choisir `Maven > Existing Maven Projects`.
4. Sélectionner le dossier du projet `tp-spring-websocket-chat`.
5. Vérifier que le fichier `pom.xml` est détecté.
6. Cliquer sur `Finish`.
7. Attendre la fin du téléchargement des dépendances Maven.

---

## 4. Lancer l'application

Dans Eclipse :

1. Ouvrir la classe :

```text
src/main/java/com/formation/chat/ChatApplication.java
```

2. Clic droit sur la classe.
3. Choisir `Run As > Java Application`.

L'application démarre sur :

```text
http://localhost:8080
```

Pour tester le chat :

1. Ouvrir deux onglets navigateur sur `http://localhost:8080`.
2. Utiliser deux pseudos différents, par exemple `Alice` et `Bob`.
3. Envoyer des messages depuis chaque onglet.
4. Constater que les messages apparaissent en temps réel dans tous les onglets.

---

## 5. Structure du projet

```text
tp-spring-websocket-chat/
├── pom.xml
├── README.md
├── src/
│   ├── main/
│   │   ├── java/com/formation/chat/
│   │   │   ├── ChatApplication.java
│   │   │   ├── config/WebSocketConfig.java
│   │   │   ├── controller/ChatController.java
│   │   │   └── dto/ChatMessage.java
│   │   └── resources/
│   │       ├── application.properties
│   │       └── static/
│   │           ├── index.html
│   │           ├── css/style.css
│   │           └── js/app.js
│   └── test/java/com/formation/chat/ChatApplicationTests.java
└── .gitignore
```

---

## 6. Comprendre le fonctionnement

### 6.1 Dépendances principales

Dans `pom.xml`, les dépendances importantes sont :

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-web</artifactId>
</dependency>

<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-websocket</artifactId>
</dependency>
```

`spring-boot-starter-websocket` ajoute le support WebSocket et STOMP côté Spring.

### 6.2 Classe principale

Fichier : `ChatApplication.java`

```java
@SpringBootApplication
public class ChatApplication {
    public static void main(String[] args) {
        SpringApplication.run(ChatApplication.class, args);
    }
}
```

Cette classe démarre l'application Spring Boot.

### 6.3 Configuration WebSocket

Fichier : `WebSocketConfig.java`

```java
@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {
```

`@EnableWebSocketMessageBroker` active le support WebSocket avec broker de messages.

```java
registry.enableSimpleBroker("/topic");
registry.setApplicationDestinationPrefixes("/app");
```

Signification :

- `/app` : préfixe des messages envoyés du client vers le serveur ;
- `/topic` : préfixe des destinations auxquelles les clients peuvent s'abonner.

```java
registry.addEndpoint("/ws-chat")
        .setAllowedOriginPatterns("*")
        .withSockJS();
```

Cette instruction expose l'endpoint de connexion WebSocket :

```text
/ws-chat
```

Le navigateur se connecte à cet endpoint avec SockJS.

### 6.4 Modèle de message

Fichier : `ChatMessage.java`

```java
public class ChatMessage {
    private String sender;
    private String content;
    private MessageType type;
    private String sentAt;
}
```

Un message contient :

- `sender` : pseudo de l'utilisateur ;
- `content` : contenu du message ;
- `type` : `CHAT`, `JOIN` ou `LEAVE` ;
- `sentAt` : heure d'envoi.

### 6.5 Contrôleur WebSocket

Fichier : `ChatController.java`

```java
@MessageMapping("/chat.send")
@SendTo("/topic/public")
public ChatMessage sendMessage(@Valid @Payload ChatMessage message) {
```

Quand le client envoie un message vers :

```text
/app/chat.send
```

Spring appelle la méthode `sendMessage`.

La réponse est diffusée à tous les clients abonnés à :

```text
/topic/public
```

### 6.6 Client JavaScript

Fichier : `app.js`

Connexion au serveur :

```javascript
const socket = new SockJS('/ws-chat');
```

Abonnement au salon public :

```javascript
stompClient.subscribe('/topic/public', onMessageReceived);
```

Envoi d'un message :

```javascript
stompClient.publish({
    destination: '/app/chat.send',
    body: JSON.stringify({
        sender: username,
        content: content,
        type: 'CHAT'
    })
});
```

---

## 7. Scénario d'animation pour le formateur

### Étape 1 : lancer l'application

Demander aux apprenants d'ouvrir deux onglets navigateur.

Questions :

- Que se passe-t-il quand un utilisateur rejoint le chat ?
- Pourquoi les deux onglets voient-ils le même message ?

### Étape 2 : analyser le flux complet

Flux d'un message :

```text
Navigateur Alice
    -> /app/chat.send
        -> ChatController.sendMessage()
            -> /topic/public
                -> Navigateur Alice
                -> Navigateur Bob
```

### Étape 3 : modifier le TP

Exercices proposés :

1. Ajouter une limite de 100 caractères au message.
2. Afficher les messages de l'utilisateur courant à droite.
3. Ajouter un compteur d'utilisateurs connectés.
4. Ajouter plusieurs salons : `/topic/salon-java`, `/topic/salon-spring`.
5. Remplacer le broker simple en mémoire par RabbitMQ ou ActiveMQ pour une architecture distribuée.

---

## 8. Questions de compréhension

1. Pourquoi HTTP classique n'est-il pas idéal pour un chat temps réel ?
2. Quel est le rôle de WebSocket ?
3. Quel est le rôle de STOMP ?
4. À quoi sert `/app` ?
5. À quoi sert `/topic` ?
6. Quelle méthode Java est appelée quand le client envoie vers `/app/chat.send` ?
7. Pourquoi utilise-t-on `@SendTo("/topic/public")` ?
8. Que se passerait-il si plusieurs instances de l'application tournaient derrière un load balancer ?

---

## 9. Limites volontairement gardées pour le TP

Ce projet est pédagogique. Il ne contient pas encore :

- authentification ;
- persistance en base de données ;
- historique des messages ;
- gestion avancée des erreurs ;
- protection CSRF/XSS complète ;
- broker externe pour le clustering.

Pour une application de production, il faudrait ajouter ces éléments.

---

## 10. Commandes Maven utiles

Compiler :

```bash
mvn clean compile
```

Lancer les tests :

```bash
mvn test
```

Démarrer l'application :

```bash
mvn spring-boot:run
```

Créer un fichier JAR :

```bash
mvn clean package
```

Lancer le JAR :

```bash
java -jar target/tp-spring-websocket-chat-1.0.0.jar
```
