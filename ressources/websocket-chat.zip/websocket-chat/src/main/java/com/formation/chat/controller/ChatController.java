package com.formation.chat.controller;

import com.formation.chat.dto.ChatMessage;
import jakarta.validation.Valid;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Controller
public class ChatController {

    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm:ss");

    @MessageMapping("/chat.send")
    @SendTo("/topic/public")
    public ChatMessage sendMessage(@Valid @Payload ChatMessage message) {
        message.setType(ChatMessage.MessageType.CHAT);
        message.setSentAt(LocalDateTime.now().format(TIME_FORMATTER));
        return message;
    }

    @MessageMapping("/chat.join")
    @SendTo("/topic/public")
    public ChatMessage join(@Valid @Payload ChatMessage message) {
        message.setType(ChatMessage.MessageType.JOIN);
        message.setContent(message.getSender() + " a rejoint le chat");
        message.setSentAt(LocalDateTime.now().format(TIME_FORMATTER));
        return message;
    }

    @MessageMapping("/chat.leave")
    @SendTo("/topic/public")
    public ChatMessage leave(@Valid @Payload ChatMessage message) {
        message.setType(ChatMessage.MessageType.LEAVE);
        message.setContent(message.getSender() + " a quitte le chat");
        message.setSentAt(LocalDateTime.now().format(TIME_FORMATTER));
        return message;
    }
}
