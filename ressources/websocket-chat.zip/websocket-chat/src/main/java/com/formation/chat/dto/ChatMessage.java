package com.formation.chat.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class ChatMessage {

    public enum MessageType {
        CHAT,
        JOIN,
        LEAVE
    }

    @NotBlank(message = "Le nom de l'expediteur est obligatoire")
    @Size(max = 30, message = "Le nom ne doit pas depasser 30 caracteres")
    private String sender;

    @Size(max = 500, message = "Le message ne doit pas depasser 500 caracteres")
    private String content;

    private MessageType type;

    private String sentAt;

    public ChatMessage() {
    }

    public ChatMessage(String sender, String content, MessageType type, String sentAt) {
        this.sender = sender;
        this.content = content;
        this.type = type;
        this.sentAt = sentAt;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public MessageType getType() {
        return type;
    }

    public void setType(MessageType type) {
        this.type = type;
    }

    public String getSentAt() {
        return sentAt;
    }

    public void setSentAt(String sentAt) {
        this.sentAt = sentAt;
    }
}
