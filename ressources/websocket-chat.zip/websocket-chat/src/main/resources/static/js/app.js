let stompClient = null;
let username = null;

const loginPage = document.querySelector('#login-page');
const chatPage = document.querySelector('#chat-page');
const loginForm = document.querySelector('#login-form');
const messageForm = document.querySelector('#message-form');
const messageInput = document.querySelector('#message');
const messageList = document.querySelector('#message-list');
const connectionStatus = document.querySelector('#connection-status');
const disconnectButton = document.querySelector('#disconnect-button');

function connect(event) {
    event.preventDefault();

    username = document.querySelector('#username').value.trim();

    if (!username) {
        return;
    }

    loginPage.classList.add('hidden');
    chatPage.classList.remove('hidden');
    connectionStatus.textContent = 'Connexion en cours...';

    const socket = new SockJS('/ws-chat');

    stompClient = new StompJs.Client({
        webSocketFactory: () => socket,
        reconnectDelay: 5000,
        debug: (message) => console.log(message),
        onConnect: onConnected,
        onStompError: onError,
        onWebSocketClose: () => {
            connectionStatus.textContent = 'Déconnecté';
        }
    });

    stompClient.activate();
}

function onConnected() {
    connectionStatus.textContent = 'Connecté en tant que ' + username;

    stompClient.subscribe('/topic/public', onMessageReceived);

    stompClient.publish({
        destination: '/app/chat.join',
        body: JSON.stringify({
            sender: username,
            type: 'JOIN'
        })
    });
}

function onError(error) {
    console.error('Erreur STOMP', error);
    connectionStatus.textContent = 'Erreur de connexion';
}

function sendMessage(event) {
    event.preventDefault();

    const content = messageInput.value.trim();

    if (content && stompClient && stompClient.connected) {
        stompClient.publish({
            destination: '/app/chat.send',
            body: JSON.stringify({
                sender: username,
                content: content,
                type: 'CHAT'
            })
        });

        messageInput.value = '';
    }
}

function onMessageReceived(payload) {
    const message = JSON.parse(payload.body);
    const item = document.createElement('li');

    if (message.type === 'JOIN' || message.type === 'LEAVE') {
        item.classList.add('system-message');
        item.textContent = '[' + message.sentAt + '] ' + message.content;
    } else {
        const meta = document.createElement('div');
        meta.classList.add('message-meta');
        meta.textContent = message.sender + ' • ' + message.sentAt;

        const content = document.createElement('div');
        content.classList.add('message-content');
        content.textContent = message.content;

        item.appendChild(meta);
        item.appendChild(content);
    }

    messageList.appendChild(item);
    messageList.scrollTop = messageList.scrollHeight;
}

function disconnect() {
    if (stompClient && stompClient.connected) {
        stompClient.publish({
            destination: '/app/chat.leave',
            body: JSON.stringify({
                sender: username,
                type: 'LEAVE'
            })
        });
        stompClient.deactivate();
    }

    messageList.innerHTML = '';
    chatPage.classList.add('hidden');
    loginPage.classList.remove('hidden');
}

loginForm.addEventListener('submit', connect);
messageForm.addEventListener('submit', sendMessage);
disconnectButton.addEventListener('click', disconnect);
window.addEventListener('beforeunload', () => {
    if (stompClient && stompClient.connected) {
        stompClient.publish({
            destination: '/app/chat.leave',
            body: JSON.stringify({ sender: username, type: 'LEAVE' })
        });
    }
});
