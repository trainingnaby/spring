package com.formation;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class Tp5Application {
 public static void main(String[] args) { SpringApplication.run(Tp5Application.class, args); }
}
