# TP démo — Tester une application Spring Boot

## Objectif

Ce petit projet sert uniquement à comprendre **les différents niveaux de tests dans une application Spring**.

Le domaine métier est volontairement simple : une API REST qui manipule des `Produit`.

Architecture :

```text
HTTP
 ↓
ProduitController
 ↓
ProduitService
 ↓
ProduitRepository
 ↓
H2
```

Nous allons tester chaque niveau séparément, puis toute la chaîne.

## Import dans Eclipse

1. Décompresser le ZIP.
2. Eclipse : `File > Import > Maven > Existing Maven Projects`.
3. Sélectionner le dossier `tp-demo-tests-spring`.
4. Attendre le téléchargement des dépendances Maven.
5. Lancer `TestsApplication` pour vérifier que l'application démarre.

Pour exécuter tous les tests :

```bash
mvn test
```

Dans Eclipse : clic droit sur `src/test/java` puis `Run As > JUnit Test`.

---

## 1. Test unitaire : qu'est-ce que cela signifie ?

Un test unitaire vérifie une petite unité de code **isolément**.

Exemple : pour tester `ProduitService`, nous ne voulons pas réellement appeler la base de données.

```text
ProduitService
      ↓
ProduitRepository
```

On remplace donc le repository réel par un **mock** :

```text
ProduitService
      ↓
 MOCK ProduitRepository
```

Un mock est un faux objet contrôlé par le test. Il permet de décider ce qu'il doit retourner et de vérifier comment il a été appelé.

Mockito est inclus avec `spring-boot-starter-test`.

---

## 2. Tester la couche service avec Mockito

Fichier :

```text
ProduitServiceTest.java
```

Le test n'a pas besoin de démarrer Spring.

```java
@ExtendWith(MockitoExtension.class)
class ProduitServiceTest {

    @Mock
    ProduitRepository repository;

    @InjectMocks
    ProduitService service;
}
```

`@Mock` crée un faux repository.

`@InjectMocks` crée le service et lui injecte le mock.

### Définir le comportement du mock

```java
when(repository.save(produit)).thenReturn(produitSauve);
```

Cela signifie :

> lorsque le service appellera `repository.save(produit)`, retourne `produitSauve`.

### Vérifier le résultat

```java
assertEquals("Clavier", resultat.getNom());
```

JUnit vérifie ici le résultat produit par le service.

### Vérifier une interaction

```java
verify(repository).save(produit);
```

Mockito vérifie que le service a réellement appelé le repository.

On peut aussi vérifier qu'une méthode **n'a jamais été appelée** :

```java
verify(repository, never()).save(any());
```

C'est utilisé dans le test du prix négatif : si la règle métier refuse le produit, aucun `save()` ne doit être effectué.

À retenir :

```text
JUnit   → vérifie les résultats
Mockito → simule les dépendances et vérifie les interactions
```

---

## 3. Tester le contrôleur

Fichier :

```text
ProduitControllerTest.java
```

Ici, on veut tester la couche Web sans tester réellement le service et la base de données.

```java
@WebMvcTest(ProduitController.class)
```

Spring démarre uniquement la partie nécessaire aux tests MVC.

Le service est remplacé par un mock Spring :

```java
@MockitoBean
ProduitService service;
```

Puis `MockMvc` simule une requête HTTP :

```java
mockMvc.perform(get("/api/produits"))
    .andExpect(status().isOk())
    .andExpect(jsonPath("$[0].nom").value("Clavier"));
```

On vérifie donc :

```text
requête HTTP
     ↓
ProduitController réel
     ↓
ProduitService MOCK
```

Le but est de tester le mapping HTTP, le statut HTTP et le JSON produit par le contrôleur.

Pour un POST :

```java
mockMvc.perform(post("/api/produits")
        .contentType("application/json")
        .content("{\"nom\":\"Ecran\",\"prix\":199}"))
    .andExpect(status().isCreated());
```

Aucun serveur HTTP réel n'est lancé par `MockMvc`.

---

## 4. Tester le repository

Fichier :

```text
ProduitRepositoryTest.java
```

Ici, utiliser un mock aurait peu d'intérêt : justement, nous voulons vérifier que notre accès JPA fonctionne réellement.

```java
@DataJpaTest
class ProduitRepositoryTest {
```

Spring configure une base de données de test H2 et la partie JPA nécessaire.

Le repository utilisé est donc **réel** :

```java
@Autowired
ProduitRepository repository;
```

Le test insère deux produits :

```java
repository.save(new Produit("Souris", 20));
repository.save(new Produit("Ecran", 200));
```

puis teste la méthode Spring Data :

```java
repository.findByPrixLessThan(100);
```

On vérifie que JPA et la requête dérivée fonctionnent réellement.

```text
ProduitRepository réel
        ↓
      JPA
        ↓
   H2 de test
```

---

## 5. Test d'intégration

Fichier :

```text
ProduitIntegrationTest.java
```

Cette fois, le but n'est plus d'isoler une classe.

Nous voulons vérifier que les différentes couches fonctionnent **ensemble** :

```text
requête HTTP réelle
       ↓
ProduitController
       ↓
ProduitService
       ↓
ProduitRepository
       ↓
       H2
```

On utilise :

```java
@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT
)
```

Spring démarre l'application et un serveur sur un port disponible.

Le test utilise `TestRestTemplate` :

```java
ResponseEntity<Produit> creation =
    rest.postForEntity(url, produit, Produit.class);
```

Cette fois il ne s'agit pas de `MockMvc` : une véritable requête HTTP est envoyée à l'application de test.

Le test crée un produit puis effectue un GET pour vérifier qu'il est réellement présent.

C'est donc un test plus complet, mais également plus lourd et généralement plus lent qu'un test unitaire.

---

## 6. Comparaison des tests du projet

| Test | Annotation principale | Spring ? | Mock ? | Base réelle de test ? | Objectif |
|---|---|---|---|---|---|
| Service | `@ExtendWith(MockitoExtension.class)` | Non | Repository | Non | logique métier |
| Controller | `@WebMvcTest` | Partiel | Service | Non | HTTP / JSON / mapping |
| Repository | `@DataJpaTest` | Partiel | Non | H2 | JPA / requêtes |
| Intégration | `@SpringBootTest` | Oui | Non | H2 | chaîne complète |

Il ne faut donc pas mettre `@SpringBootTest` partout.

Pour tester une règle métier simple du service, démarrer toute l'application serait inutile.

---

## 7. Quelques notions JUnit utilisées

```java
@Test
```

indique une méthode de test.

```java
@BeforeEach
```

exécute une méthode avant chaque test.

```java
assertEquals(attendu, obtenu);
```

compare deux valeurs.

```java
assertNotNull(valeur);
```

vérifie qu'une valeur n'est pas `null`.

```java
assertThrows(...)
```

vérifie qu'une exception est bien déclenchée.

Chaque test doit idéalement être indépendant des autres.

---

## 8. La logique générale à retenir

```text
             TESTS RAPIDES / ISOLÉS

Service ------------------> Mockito
Controller ---------------> @WebMvcTest + MockMvc
Repository ---------------> @DataJpaTest + H2

             TEST PLUS COMPLET

Controller
    ↓
Service             @SpringBootTest
    ↓                       +
Repository            serveur de test
    ↓                       +
H2                  TestRestTemplate
```

Un bon projet possède généralement beaucoup de tests ciblés et quelques tests d'intégration pour vérifier que les briques fonctionnent correctement ensemble.

---

## 9. Manipulations proposées pendant la démo

1. Lancer tous les tests et constater qu'ils sont verts.
2. Modifier volontairement `ProduitService.creer()` pour accepter un prix négatif : le test service doit échouer.
3. Modifier le statut du POST de `201 Created` vers `200 OK` : le test contrôleur doit échouer.
4. Modifier la requête repository ou le seuil du test : observer l'échec du test JPA.
5. Mettre un point d'arrêt dans le contrôleur, le service et le repository pendant `ProduitIntegrationTest` pour visualiser le passage dans toutes les couches.

La question à poser aux stagiaires à chaque fois est :

> **Quelle partie de l'application suis-je réellement en train de tester ?**
