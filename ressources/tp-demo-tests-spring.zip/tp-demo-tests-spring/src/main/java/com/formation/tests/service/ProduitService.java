package com.formation.tests.service;

import com.formation.tests.model.Produit;
import com.formation.tests.repository.ProduitRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ProduitService {
	private final ProduitRepository repository;

	public ProduitService(ProduitRepository repository) {
		this.repository = repository;
	}

	public List<Produit> lister() {
		return repository.findAll();
	}

	public Produit trouver(Long id) {
		return repository.findById(id).orElseThrow(() -> new IllegalArgumentException("Produit introuvable : " + id));
	}

	public Produit creer(Produit produit) {
		if (produit.getPrix() < 0)
			throw new IllegalArgumentException("Le prix doit être positif");
		return repository.save(produit);
	}

	public List<Produit> produitsMoinsChersQue(double prix) {
		return repository.findByPrixLessThan(prix);
	}
}
