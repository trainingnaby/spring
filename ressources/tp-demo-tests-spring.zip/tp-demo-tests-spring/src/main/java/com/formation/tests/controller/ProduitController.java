package com.formation.tests.controller;

import com.formation.tests.model.Produit;
import com.formation.tests.service.ProduitService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/produits")
public class ProduitController {
	private final ProduitService service;

	public ProduitController(ProduitService service) {
		this.service = service;
	}

	@GetMapping
	public List<Produit> lister() {
		return service.lister();
	}

	@GetMapping("/{id}")
	public Produit trouver(@PathVariable Long id) {
		return service.trouver(id);
	}

	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public Produit creer(@RequestBody Produit produit) {
		return service.creer(produit);
	}
}
