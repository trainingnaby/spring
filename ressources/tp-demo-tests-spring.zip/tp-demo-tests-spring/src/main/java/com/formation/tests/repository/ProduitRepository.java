package com.formation.tests.repository;

import com.formation.tests.model.Produit;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ProduitRepository extends JpaRepository<Produit, Long> {
	List<Produit> findByPrixLessThan(double prix);
}
