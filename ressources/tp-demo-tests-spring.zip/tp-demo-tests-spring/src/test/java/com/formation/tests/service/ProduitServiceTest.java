package com.formation.tests.service;

import com.formation.tests.model.Produit;
import com.formation.tests.repository.ProduitRepository;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProduitServiceTest {
	@Mock
	ProduitRepository repository;
	@InjectMocks
	ProduitService service;

	@Test
	void creer_enregistre_le_produit() {
		Produit p = new Produit("Clavier", 49.90);
		Produit sauve = new Produit(1L, "Clavier", 49.90);
		when(repository.save(p)).thenReturn(sauve);
		Produit resultat = service.creer(p);
		assertEquals(1L, resultat.getId());
		assertEquals("Clavier", resultat.getNom());
		verify(repository).save(p);
	}

	@Test
	void creer_refuse_un_prix_negatif() {
		Produit p = new Produit("Erreur", -1);
		IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> service.creer(p));
		assertEquals("Le prix doit être positif", ex.getMessage());
		verify(repository, never()).save(any());
	}

	@Test void trouver_retourne_le_produit(){
   when(repository.findById(1L)).thenReturn(Optional.of(new Produit(1L,"Souris",20)));
   assertEquals("Souris",service.trouver(1L).getNom());
 }
}
