package com.formation.tests.controller;

import com.formation.tests.model.Produit;
import com.formation.tests.service.ProduitService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import java.util.List;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ProduitController.class)
class ProduitControllerTest {
	@Autowired
	MockMvc mockMvc;
	@MockitoBean
	ProduitService service;

	@Test void get_produits_retourne_du_json() throws Exception {
   when(service.lister()).thenReturn(List.of(new Produit(1L,"Clavier",49.90)));
   mockMvc.perform(get("/api/produits"))
     .andExpect(status().isOk()).andExpect(jsonPath("$[0].nom").value("Clavier"));
   verify(service).lister();
 }

	@Test void post_produit_retourne_201() throws Exception {
   when(service.creer(any(Produit.class))).thenReturn(new Produit(1L,"Ecran",199.0));
   mockMvc.perform(post("/api/produits").contentType("application/json").content("{\"nom\":\"Ecran\",\"prix\":199}"))
     .andExpect(status().isCreated()).andExpect(jsonPath("$.id").value(1)).andExpect(jsonPath("$.nom").value("Ecran"));
 }
}
