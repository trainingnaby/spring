package com.formation.tests.repository;

import com.formation.tests.model.Produit;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
class ProduitRepositoryTest {
	@Autowired
	ProduitRepository repository;

	@Test
	void findByPrixLessThan_filtre_les_produits() {
		repository.save(new Produit("Souris", 20));
		repository.save(new Produit("Ecran", 200));
		List<Produit> resultats = repository.findByPrixLessThan(100);
		assertEquals(1, resultats.size());
		assertEquals("Souris", resultats.get(0).getNom());
	}
}
