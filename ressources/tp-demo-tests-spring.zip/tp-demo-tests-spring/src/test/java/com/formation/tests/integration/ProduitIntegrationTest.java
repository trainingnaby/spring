package com.formation.tests.integration;

import com.formation.tests.model.Produit;
import com.formation.tests.repository.ProduitRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.*;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class ProduitIntegrationTest {
	@LocalServerPort
	int port;
	@Autowired
	TestRestTemplate rest;
	@Autowired
	ProduitRepository repository;

	@BeforeEach
	void nettoyer() {
		repository.deleteAll();
	}

	@Test
	void creation_puis_lecture_traverse_toutes_les_couches() {
		String url = "http://localhost:" + port + "/api/produits";
		ResponseEntity<Produit> creation = rest.postForEntity(url, new Produit("Webcam", 79.0), Produit.class);
		assertEquals(HttpStatus.CREATED, creation.getStatusCode());
		assertNotNull(creation.getBody().getId());
		ResponseEntity<Produit[]> liste = rest.getForEntity(url, Produit[].class);
		assertEquals(HttpStatus.OK, liste.getStatusCode());
		assertEquals(1, liste.getBody().length);
		assertEquals("Webcam", liste.getBody()[0].getNom());
	}
}
