package com.formation.config;

import java.io.IOException;
import java.net.URI;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ProblemDetail;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    /*
     * ============================================================
     * SECURITE REST
     * ============================================================
     *
     * Cette chaîne est dédiée aux endpoints REST.
     *
     * Contrairement à la partie MVC :
     * - pas de formulaire de login
     * - pas de session HTTP
     * - authentification HTTP Basic
     * - réponses 401/403 en JSON
     *
     * PARTIE A COMPLETER
     */
    @Bean
    @Order(1)
    SecurityFilterChain apiSecurityFilterChain(
            HttpSecurity http,
            AuthenticationEntryPoint restAuthenticationEntryPoint,
            AccessDeniedHandler restAccessDeniedHandler) throws Exception {

        return http

                /*
                 * TODO 1
                 *
                 * Indiquer que cette chaîne concerne uniquement :
                 *
                 * /duplicatas
                 * /duplicatas/**
                 * /duplicatas_dto
                 * /duplicatas_dto/**
                 * /api/cache
                 * /api/cache/**
                 */


                /*
                 * Configuration CORS fournie.
                 */
                .cors(Customizer.withDefaults())


                /*
                 * TODO 2
                 *
                 * L'API REST doit fonctionner sans session HTTP.
                 *
                 * - désactiver CSRF
                 * - configurer la session en STATELESS
                 */


                /*
                 * TODO 3
                 *
                 * Pour cette API REST :
                 *
                 * - désactiver le formulaire de login
                 * - désactiver le logout
                 * - activer HTTP Basic
                 */


                /*
                 * Gestion des erreurs REST fournie.
                 *
                 * 401 : utilisateur non authentifié
                 * 403 : utilisateur authentifié mais non autorisé
                 */
                .exceptionHandling(ex -> ex
                        .authenticationEntryPoint(restAuthenticationEntryPoint)
                        .accessDeniedHandler(restAccessDeniedHandler))


                /*
                 * TODO 4
                 *
                 * Compléter les règles :
                 *
                 * GET /duplicatas et /duplicatas/**
                 *      -> USER ou ADMIN
                 *
                 * POST /duplicatas et /duplicatas/**
                 *      -> ADMIN
                 *
                 * POST /duplicatas_dto
                 *      -> ADMIN
                 *
                 * DELETE /duplicatas/**
                 *      -> ADMIN
                 *
                 * /api/cache et /api/cache/**
                 *      -> ADMIN
                 *
                 * Toute autre requête doit être authentifiée.
                 */
                .authorizeHttpRequests(auth -> auth

                        // A COMPLETER

                )

                .build();
    }


    /*
     * ============================================================
     * SECURITE MVC / THYMELEAF
     * ============================================================
     *
     * Configuration réalisée dans la première partie du TP.
     * Ne pas modifier.
     */
    @Bean
    @Order(2)
    SecurityFilterChain mvcSecurityFilterChain(HttpSecurity http)
            throws Exception {

        return http

                .cors(Customizer.withDefaults())

                .csrf(csrf -> csrf
                        .ignoringRequestMatchers("/h2-console/**"))

                .headers(headers ->
                        headers.frameOptions(frame -> frame.sameOrigin()))

                .authorizeHttpRequests(auth -> auth

                        // Ressources publiques
                        .requestMatchers(
                                "/css/**",
                                "/images/**",
                                "/js/**",
                                "/favicon.ico",
                                "/error")
                        .permitAll()

                        .requestMatchers(
                                "/login",
                                "/access-denied")
                        .permitAll()

                        // Swagger / OpenAPI
                        .requestMatchers(
                                "/swagger-ui.html",
                                "/swagger-ui/**",
                                "/v3/api-docs/**")
                        .permitAll()

                        // Console H2
                        .requestMatchers("/h2-console/**")
                        .permitAll()

                        // Actuator
                        .requestMatchers(
                                "/actuator/health/**",
                                "/actuator/info")
                        .permitAll()

                        .requestMatchers("/actuator/**")
                        .hasRole("ADMIN")

                        // Création : ADMIN
                        .requestMatchers(
                                HttpMethod.GET,
                                "/ui/duplicatas/new")
                        .hasRole("ADMIN")

                        // Création / suppression : ADMIN
                        .requestMatchers(
                                HttpMethod.POST,
                                "/ui/duplicatas",
                                "/ui/duplicatas/*/delete")
                        .hasRole("ADMIN")

                        // Consultation : USER ou ADMIN
                        .requestMatchers(
                                HttpMethod.GET,
                                "/ui/duplicatas",
                                "/ui/duplicatas/*")
                        .hasAnyRole("USER", "ADMIN")

                        // Accueil
                        .requestMatchers("/")
                        .permitAll()

                        // Toutes les autres pages
                        .anyRequest()
                        .authenticated())

                .formLogin(form -> form
                        .loginPage("/login")
                        .defaultSuccessUrl(
                                "/ui/duplicatas",
                                true)
                        .permitAll())

                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/login?logout")
                        .permitAll())

                .exceptionHandling(ex ->
                        ex.accessDeniedPage("/access-denied"))

                .build();
    }


    /*
     * ============================================================
     * UTILISATEURS
     * ============================================================
     */

    @Bean
    UserDetailsService userDetailsService(
            PasswordEncoder passwordEncoder) {

        UserDetails lecteur =
                org.springframework.security.core.userdetails.User
                        .withUsername("user")
                        .password(passwordEncoder.encode("user"))
                        .roles("USER")
                        .build();

        UserDetails admin =
                org.springframework.security.core.userdetails.User
                        .withUsername("admin")
                        .password(passwordEncoder.encode("admin"))
                        .roles("USER", "ADMIN")
                        .build();

        return new InMemoryUserDetailsManager(
                lecteur,
                admin);
    }


    @Bean
    PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }


    /*
     * ============================================================
     * CORS
     * ============================================================
     *
     * Configuration fournie.
     * Ne pas modifier dans ce TP.
     */

    @Bean
    CorsConfigurationSource corsConfigurationSource() {

        CorsConfiguration configuration =
                new CorsConfiguration();

        configuration.setAllowedOrigins(
                List.of(
                        "http://localhost:3000",
                        "http://127.0.0.1:5500"));

        configuration.setAllowedMethods(
                List.of(
                        "GET",
                        "POST",
                        "PUT",
                        "DELETE",
                        "OPTIONS"));

        configuration.setAllowedHeaders(
                List.of(
                        "Authorization",
                        "Content-Type",
                        "X-Requested-With"));

        configuration.setExposedHeaders(
                List.of("WWW-Authenticate"));

        configuration.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source =
                new UrlBasedCorsConfigurationSource();

        source.registerCorsConfiguration(
                "/**",
                configuration);

        return source;
    }


    /*
     * ============================================================
     * GESTION DES ERREURS REST
     * ============================================================
     *
     * Code fourni
     * 
     */


    /*
     * Utilisé lorsqu'un utilisateur non authentifié
     * tente d'accéder à une ressource protégée.
     *
     * -> HTTP 401
     */
    @Bean
    AuthenticationEntryPoint restAuthenticationEntryPoint(
            ObjectMapper objectMapper) {

        return (request, response, authException) -> {

            response.setHeader(
                    "WWW-Authenticate",
                    "Basic realm=\"duplicata-api\"");

            writeProblemDetail(
                    objectMapper,
                    request,
                    response,
                    HttpStatus.UNAUTHORIZED,
                    "Authentification requise",
                    "Vous devez fournir un identifiant et un mot de passe valides pour appeler cette API REST.");
        };
    }


    /*
     * Utilisé lorsque l'utilisateur est bien authentifié
     * mais ne possède pas les droits nécessaires.
     *
     * -> HTTP 403
     */
    @Bean
    AccessDeniedHandler restAccessDeniedHandler(
            ObjectMapper objectMapper) {

        return (request, response, accessDeniedException) ->
                writeProblemDetail(
                        objectMapper,
                        request,
                        response,
                        HttpStatus.FORBIDDEN,
                        "Acces refuse",
                        "Votre compte est authentifie, mais il ne possede pas les droits suffisants pour cette operation.");
    }


    /*
     * Construction d'une réponse JSON standardisée
     * au format ProblemDetail.
     */
    private static void writeProblemDetail(
            ObjectMapper objectMapper,
            HttpServletRequest request,
            HttpServletResponse response,
            HttpStatus status,
            String title,
            String detail)
            throws IOException, ServletException {

        ProblemDetail problem =
                ProblemDetail.forStatusAndDetail(
                        status,
                        detail);

        problem.setTitle(title);

        problem.setType(
                URI.create(
                        "https://formation.spring/erreurs/securite"));

        problem.setInstance(
                URI.create(request.getRequestURI()));

        problem.setProperty(
                "method",
                request.getMethod());

        problem.setProperty(
                "path",
                request.getRequestURI());

        response.setStatus(status.value());

        response.setContentType(
                MediaType.APPLICATION_PROBLEM_JSON_VALUE);

        objectMapper.writeValue(
                response.getOutputStream(),
                problem);
    }
}