package com.formation.webflux.controller;

import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.reactive.server.WebTestClient;

import com.formation.webflux.model.Produit;
import com.formation.webflux.service.ProduitService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@WebFluxTest(ProduitController.class)
class ProduitControllerTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockitoBean
    private ProduitService produitService;

    @Test
    void getProduitRetourneUnProduit() {
        when(produitService.findById(1L))
                .thenReturn(Mono.just(new Produit(1L, "Clavier", 49.90)));

        webTestClient.get()
                .uri("/api/produits/1")
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.nom").isEqualTo("Clavier")
                .jsonPath("$.prix").isEqualTo(49.90);
    }

    @Test
    void getProduitsRetourneUneListe() {
        when(produitService.findAll()).thenReturn(Flux.just(
                new Produit(1L, "Clavier", 49.90),
                new Produit(2L, "Souris", 24.90)
        ));

        webTestClient.get()
                .uri("/api/produits")
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$[0].nom").isEqualTo("Clavier")
                .jsonPath("$[1].nom").isEqualTo("Souris");
    }
}
