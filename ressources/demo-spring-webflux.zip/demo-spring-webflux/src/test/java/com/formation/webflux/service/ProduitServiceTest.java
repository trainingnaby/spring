package com.formation.webflux.service;

import org.junit.jupiter.api.Test;

import com.formation.webflux.model.Produit;

import reactor.test.StepVerifier;

class ProduitServiceTest {

    private final ProduitService service = new ProduitService();

    @Test
    void findByIdRetourneLeProduit() {
        StepVerifier.create(service.findById(1L))
                .expectNext(new Produit(1L, "Clavier", 49.90))
                .verifyComplete();
    }

    @Test
    void findByIdInconnuRetourneUnMonoVide() {
        StepVerifier.create(service.findById(999L))
                .verifyComplete();
    }

    @Test
    void findAllRetourneQuatreProduits() {
        StepVerifier.create(service.findAll())
                .expectNextCount(4)
                .verifyComplete();
    }
}
