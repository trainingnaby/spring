package com.formation.webflux.controller;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.formation.webflux.model.Produit;
import com.formation.webflux.service.ProduitService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/produits")
public class ProduitController {

    private final ProduitService produitService;

    public ProduitController(ProduitService produitService) {
        this.produitService = produitService;
    }

    @GetMapping
    public Flux<Produit> findAll() {
        return produitService.findAll();
    }

    @GetMapping("/{id}")
    public Mono<Produit> findById(@PathVariable Long id) {
        return produitService.findById(id);
    }

    @GetMapping("/recherche")
    public Flux<Produit> rechercher(@RequestParam double prixMax) {
        return produitService.findByPrixMaximum(prixMax);
    }

    /*
     * TEXT_EVENT_STREAM permet de garder la réponse ouverte.
     * Les produits sont envoyés au navigateur au fur et à mesure.
     */
    @GetMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<Produit> stream() {
        return produitService.streamProduits();
    }

    @GetMapping("/lent")
    public Mono<String> traitementLent() {
        return produitService.traitementLent();
    }
}
