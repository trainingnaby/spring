package com.formation.webflux.service;

import java.time.Duration;
import java.util.List;

import org.springframework.stereotype.Service;

import com.formation.webflux.model.Produit;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class ProduitService {

    private final List<Produit> produits = List.of(
            new Produit(1L, "Clavier", 49.90),
            new Produit(2L, "Souris", 24.90),
            new Produit(3L, "Ecran", 229.00),
            new Produit(4L, "Casque", 79.90)
    );

    public Flux<Produit> findAll() {
        return Flux.fromIterable(produits);
    }

    public Mono<Produit> findById(Long id) {
        return Flux.fromIterable(produits)
                .filter(produit -> produit.id().equals(id))
                .next();
    }

    public Flux<Produit> findByPrixMaximum(double prixMaximum) {
        return Flux.fromIterable(produits)
                .filter(produit -> produit.prix() <= prixMaximum);
    }

    /*
     * Démo pédagogique :
     * un élément est émis toutes les secondes.
     * On peut voir les données arriver progressivement dans le navigateur.
     */
    public Flux<Produit> streamProduits() {
        return Flux.fromIterable(produits)
                .delayElements(Duration.ofSeconds(1));
    }

    /*
     * Mono représente ici une valeur qui sera disponible plus tard.
     * delayElement ne bloque pas le thread pendant deux secondes.
     */
    public Mono<String> traitementLent() {
        return Mono.just("Traitement terminé")
                .delayElement(Duration.ofSeconds(2));
    }
}
