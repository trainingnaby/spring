package com.formation.webflux.model;

public record Produit(Long id, String nom, double prix) {
}
