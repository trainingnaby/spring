# Démo - Introduction à Spring WebFlux

## Objectif

Ce petit projet sert à découvrir **Spring WebFlux** avant de passer à un TP plus complet.

Il ne contient volontairement :

- ni base de données ;
- ni sécurité ;
- ni architecture complexe.

Le but est de voir clairement les notions suivantes :

- `Mono<T>` ;
- `Flux<T>` ;
- `map`, `filter` et les pipelines réactifs ;
- émission progressive de données ;
- différence entre une réponse REST classique et un flux ;
- `WebTestClient` ;
- `StepVerifier`.

---

# 1. Importer le projet dans Eclipse

Dans Eclipse :

```text
File
  -> Import
  -> Maven
  -> Existing Maven Projects
```

Sélectionner le dossier du projet puis terminer l'import.

Le projet nécessite **Java 17 ou supérieur**.

Classe principale :

```text
com.formation.webflux.DemoWebFluxApplication
```

Lancer avec :

```text
Run As -> Spring Boot App
```

L'application démarre sur :

```text
http://localhost:8080
```

---

# 2. L'architecture

Le projet reste volontairement très simple :

```text
HTTP
 |
 v
ProduitController
 |
 v
ProduitService
 |
 v
Mono / Flux
```

Ici, nous n'utilisons pas encore de repository.

Cela permet de se concentrer sur la programmation réactive.

---

# 3. Premier point à observer : les types retournés

Dans une application Spring MVC classique, on pourrait écrire :

```java
public Produit findById(Long id)
```

ou :

```java
public List<Produit> findAll()
```

Dans cette application WebFlux :

```java
public Mono<Produit> findById(Long id)
```

et :

```java
public Flux<Produit> findAll()
```

La différence est importante.

---

# 4. Mono

Un `Mono<T>` représente :

```text
0 ou 1 valeur
```

Exemple :

```java
public Mono<Produit> findById(Long id) {
    return Flux.fromIterable(produits)
            .filter(produit -> produit.id().equals(id))
            .next();
}
```

Si le produit existe :

```text
Mono
 |
 +----> Produit
 |
 +----> terminé
```

S'il n'existe pas :

```text
Mono
 |
 +----> aucune valeur
 |
 +----> terminé
```

Un `Mono<Produit>` n'est donc pas simplement un `Produit` placé dans une boîte.

Il représente une **source réactive** capable de produire une valeur plus tard.

---

# 5. Flux

Un `Flux<T>` représente :

```text
0 à N valeurs
```

Exemple :

```java
public Flux<Produit> findAll() {
    return Flux.fromIterable(produits);
}
```

Conceptuellement :

```text
Flux<Produit>

   |
   +--> Clavier
   |
   +--> Souris
   |
   +--> Ecran
   |
   +--> Casque
   |
   +--> COMPLETE
```

---

# 6. Tester les premières URL

### Tous les produits

```text
GET http://localhost:8080/api/produits
```

Avec curl :

```bash
curl http://localhost:8080/api/produits
```

### Un produit

```bash
curl http://localhost:8080/api/produits/1
```

### Recherche

```bash
curl "http://localhost:8080/api/produits/recherche?prixMax=60"
```

Le service utilise :

```java
.filter(produit -> produit.prix() <= prixMaximum)
```

Nous commençons donc à construire un petit pipeline réactif.

---

# 7. Le point important : un Flux ne signifie pas forcément streaming

Cette méthode :

```java
@GetMapping
public Flux<Produit> findAll() {
    return produitService.findAll();
}
```

retourne bien un `Flux`.

Mais pour un appel HTTP JSON classique, le client peut recevoir au final un tableau JSON :

```json
[
  {"id":1,"nom":"Clavier","prix":49.9},
  {"id":2,"nom":"Souris","prix":24.9}
]
```

Le simple fait d'utiliser `Flux` ne signifie donc pas que l'utilisateur verra obligatoirement les éléments apparaître un par un à l'écran.

---

# 8. Visualiser réellement le temps réel

La méthode la plus intéressante de la démo est :

```java
public Flux<Produit> streamProduits() {
    return Flux.fromIterable(produits)
            .delayElements(Duration.ofSeconds(1));
}
```

Le contrôleur expose :

```java
@GetMapping(
    value = "/stream",
    produces = MediaType.TEXT_EVENT_STREAM_VALUE
)
public Flux<Produit> stream() {
    return produitService.streamProduits();
}
```

Tester avec :

```bash
curl -N http://localhost:8080/api/produits/stream
```

Ne pas oublier `-N` avec curl pour désactiver son buffering.

Vous devez voir les produits arriver progressivement :

```text
1 seconde
   |
   +--> Clavier

1 seconde
   |
   +--> Souris

1 seconde
   |
   +--> Ecran

1 seconde
   |
   +--> Casque
```

C'est une bonne première visualisation de la notion de **flux**.

---

# 9. Pourquoi delayElements est intéressant ?

Le code :

```java
.delayElements(Duration.ofSeconds(1))
```

ne signifie pas :

```java
Thread.sleep(1000);
```

`Thread.sleep` bloque le thread.

Avec Reactor, le délai est géré de manière réactive.

L'idée est :

```text
produit 1
   |
   | attente sans immobiliser le thread appelant
   v
émission

produit 2
   |
   | attente
   v
émission
```

C'est précisément l'un des changements de raisonnement importants avec WebFlux.

---

# 10. Démo Mono avec une opération lente

Tester :

```bash
curl http://localhost:8080/api/produits/lent
```

Le service contient :

```java
return Mono.just("Traitement terminé")
        .delayElement(Duration.ofSeconds(2));
```

La réponse arrive après environ deux secondes.

Mais nous n'avons pas écrit :

```java
Thread.sleep(2000);
```

C'est la différence que l'on veut faire observer.

---

# 11. Pipeline réactif

Avec Reactor, on décrit souvent une succession d'opérations :

```text
SOURCE
  |
  v
filter(...)
  |
  v
map(...)
  |
  v
flatMap(...)
  |
  v
résultat
```

Par exemple :

```java
Flux.fromIterable(produits)
    .filter(p -> p.prix() < 100)
    .map(Produit::nom);
```

On peut lire :

```text
prendre les produits
        |
        v
garder ceux à moins de 100 €
        |
        v
extraire leur nom
```

---

# 12. map et flatMap

`map` est utilisé lorsqu'une valeur est transformée directement :

```java
.map(produit -> produit.nom())
```

On a :

```text
Produit -> String
```

`flatMap` devient particulièrement important lorsque la fonction appelée retourne elle-même un type réactif :

```text
Produit -> Mono<AutreObjet>
```

On écrit alors typiquement :

```java
.flatMap(produit -> service.appelReactif(produit))
```

Cela évite de fabriquer :

```text
Mono<Mono<AutreObjet>>
```

Cette démo reste volontairement simple ; `flatMap` pourra être approfondi dans le TP suivant.

---

# 13. Qui appelle subscribe() ?

Dans une petite application Reactor autonome, on pourrait écrire :

```java
flux.subscribe(...);
```

Mais dans un contrôleur Spring WebFlux, on écrit simplement :

```java
@GetMapping
public Flux<Produit> findAll() {
    return produitService.findAll();
}
```

On ne fait généralement pas :

```java
produitService.findAll().subscribe();
```

Spring WebFlux prend en charge la souscription nécessaire pour produire la réponse HTTP.

C'est une règle importante à retenir.

---

# 14. Tester du code réactif avec StepVerifier

Le projet contient :

```text
ProduitServiceTest
```

Exemple :

```java
StepVerifier.create(service.findById(1L))
        .expectNext(new Produit(1L, "Clavier", 49.90))
        .verifyComplete();
```

`StepVerifier` permet de vérifier les événements produits par un `Mono` ou un `Flux`.

On peut lire ce test ainsi :

```text
je m'abonne au Mono
       |
       v
j'attends ce Produit
       |
       v
j'attends la fin normale du flux
```

Pour un `Flux` :

```java
StepVerifier.create(service.findAll())
        .expectNextCount(4)
        .verifyComplete();
```

---

# 15. Tester un contrôleur WebFlux

Spring fournit :

```text
WebTestClient
```

Le projet contient :

```text
ProduitControllerTest
```

Le test charge uniquement la partie Web :

```java
@WebFluxTest(ProduitController.class)
```

Le service est remplacé par un mock :

```java
@MockitoBean
private ProduitService produitService;
```

Puis :

```java
when(produitService.findById(1L))
    .thenReturn(
        Mono.just(
            new Produit(1L, "Clavier", 49.90)
        )
    );
```

Enfin :

```java
webTestClient.get()
    .uri("/api/produits/1")
    .exchange()
    .expectStatus().isOk()
    .expectBody()
    .jsonPath("$.nom").isEqualTo("Clavier");
```

C'est l'équivalent WebFlux de ce que l'on fait souvent avec `MockMvc` dans Spring MVC.

---

# 16. MVC et WebFlux : comparaison rapide

Spring MVC :

```java
@GetMapping("/{id}")
public Produit findById(@PathVariable Long id) {
    return service.findById(id);
}
```

WebFlux :

```java
@GetMapping("/{id}")
public Mono<Produit> findById(@PathVariable Long id) {
    return service.findById(id);
}
```

Mais la différence réelle ne se limite pas au type de retour.

Pour bénéficier réellement du modèle non bloquant, les différentes couches doivent être compatibles avec cette approche.

---

# 17. Attention au faux WebFlux

Ce code retourne un `Mono` :

```java
public Mono<Produit> find() {

    Produit produit = repositoryJpa.findById(1L).orElseThrow();

    return Mono.just(produit);
}
```

Mais l'appel :

```java
repositoryJpa.findById(...)
```

est toujours bloquant si l'on utilise JPA/JDBC classique.

Mettre :

```java
Mono.just(...)
```

autour d'un appel bloquant ne transforme pas magiquement cet appel en opération non bloquante.

C'est une notion essentielle.

---

# 18. WebFlux et base de données

Dans une architecture réellement réactive, on cherchera un accès aux données compatible avec le modèle non bloquant.

Par exemple, dans l'écosystème Spring :

```text
Spring Data R2DBC
```

plutôt qu'un accès JDBC/JPA classique lorsque l'objectif est une chaîne réactive de bout en bout.

Schéma :

```text
Controller WebFlux
        |
        v
Service réactif
        |
        v
Repository réactif
        |
        v
Driver non bloquant
```

Cette démo n'introduit volontairement pas R2DBC afin de ne pas mélanger trop de notions.

---

# 19. Exercices rapides

## Exercice 1

Ajouter :

```text
GET /api/produits/noms
```

qui retourne :

```text
Flux<String>
```

contenant uniquement les noms.

Indice :

```java
.map(...)
```

---

## Exercice 2

Ajouter :

```text
GET /api/produits/chers
```

qui retourne uniquement les produits dont le prix est supérieur à 50 €.

Indice :

```java
.filter(...)
```

---

## Exercice 3

Modifier le streaming pour envoyer un produit toutes les deux secondes.

Observer la différence avec :

```bash
curl -N http://localhost:8080/api/produits/stream
```

---

## Exercice 4

Ajouter un test `StepVerifier` pour vérifier que :

```java
findByPrixMaximum(50)
```

retourne exactement :

```text
Clavier
Souris
```

---

# 20. À retenir

```text
Mono<T>
    = 0 ou 1 valeur

Flux<T>
    = 0 à N valeurs
```

Les opérateurs permettent de construire un pipeline :

```text
source
  |
filter
  |
map
  |
flatMap
  |
résultat
```

WebFlux est particulièrement intéressant lorsque l'application effectue beaucoup d'opérations d'entrée/sortie et doit gérer de nombreuses requêtes concurrentes.

Mais :

```text
WebFlux != automatiquement plus rapide
```

et :

```text
Mono.just(appelBloquant())
```

ne rend pas l'appel non bloquant.

La question à se poser n'est donc pas :

```text
"WebFlux est-il meilleur que Spring MVC ?"
```

mais plutôt :

```text
"Mon application a-t-elle un besoin qui justifie
un modèle réactif et non bloquant ?"
```

---

# Commandes utiles

Lancer les tests :

```bash
mvn test
```

Lancer l'application :

```bash
mvn spring-boot:run
```

Tester la liste :

```bash
curl http://localhost:8080/api/produits
```

Tester un produit :

```bash
curl http://localhost:8080/api/produits/1
```

Tester le streaming :

```bash
curl -N http://localhost:8080/api/produits/stream
```

Tester l'opération différée :

```bash
curl http://localhost:8080/api/produits/lent
```
