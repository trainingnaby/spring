package com.formation.config;

import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        return http
                /*
                 * Configuration fournie.
                 * Ces parties ne sont pas à modifier dans ce TP.
                 */
                .cors(Customizer.withDefaults())

                .csrf(csrf -> csrf
                        .ignoringRequestMatchers("/h2-console/**")

                        // API REST non sécurisée dans ce TP.
                        // Elle sera traitée ultérieurement.
                        .ignoringRequestMatchers(
                                "/duplicatas", "/duplicatas/**",
                                "/duplicatas_dto", "/duplicatas_dto/**",
                                "/cache", "/cache/**"
                        ))

                .headers(headers ->
                        headers.frameOptions(frame -> frame.sameOrigin()))

                /*
                 * =====================================================
                 * PARTIE À COMPLÉTER
                 * =====================================================
                 */
                .authorizeHttpRequests(auth -> auth

                        // TODO 1 :
                        // Autoriser les ressources statiques,
                        // /login, /access-denied et /error


                        // TODO 2 :
                        // Laisser accessibles Swagger/OpenAPI
                        // et la console H2


                        // TODO 3 :
                        // Autoriser publiquement health et info.
                        // Réserver les autres endpoints Actuator à ADMIN.


                        // TODO 4 :
                        // Whitelister les API REST :
                        // /duplicatas/**
                        // /duplicatas_dto/**
                        // /cache/**
                        //
                        // Leur sécurité sera traitée dans un prochain TP.


                        // TODO 5 :
                        // Partie Web MVC :
                        //
                        // GET /ui/duplicatas/new
                        //     -> ADMIN
                        //
                        // POST /ui/duplicatas
                        // POST /ui/duplicatas/*/delete
                        //     -> ADMIN
                        //
                        // GET /ui/duplicatas
                        // GET /ui/duplicatas/*
                        //     -> USER ou ADMIN


                        // TODO 6 :
                        // La racine "/" est publique.


                        // TODO 7 :
                        // Toute autre requête nécessite
                        // une authentification.

                )

                /*
                 * Configuration fournie.
                 */
                .formLogin(form -> form
                        .loginPage("/login")
                        .defaultSuccessUrl("/ui/duplicatas", true)
                        .permitAll())

                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/login?logout")
                        .permitAll())

                .exceptionHandling(ex ->
                        ex.accessDeniedPage("/access-denied"))

                .build();
    }

    /*
     * Utilisateurs fournis pour le TP.
     */
    @Bean
    UserDetailsService userDetailsService(
            PasswordEncoder passwordEncoder) {

        UserDetails lecteur =
                org.springframework.security.core.userdetails.User
                        .withUsername("user")
                        .password(passwordEncoder.encode("user"))
                        .roles("USER")
                        .build();

        UserDetails admin =
                org.springframework.security.core.userdetails.User
                        .withUsername("admin")
                        .password(passwordEncoder.encode("admin"))
                        .roles("USER", "ADMIN")
                        .build();

        return new InMemoryUserDetailsManager(lecteur, admin);
    }

    @Bean
    PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /*
     * Configuration CORS fournie.
     * Ne pas modifier dans ce TP.
     */
    @Bean
    CorsConfigurationSource corsConfigurationSource() {

        CorsConfiguration configuration =
                new CorsConfiguration();

        configuration.setAllowedOrigins(
                List.of(
                        "http://localhost:3000",
                        "http://127.0.0.1:5500"
                ));

        configuration.setAllowedMethods(
                List.of("GET", "POST", "PUT",
                        "DELETE", "OPTIONS"));

        configuration.setAllowedHeaders(
                List.of(
                        "Authorization",
                        "Content-Type",
                        "X-Requested-With"
                ));

        configuration.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source =
                new UrlBasedCorsConfigurationSource();

        source.registerCorsConfiguration(
                "/**", configuration);

        return source;
    }
}