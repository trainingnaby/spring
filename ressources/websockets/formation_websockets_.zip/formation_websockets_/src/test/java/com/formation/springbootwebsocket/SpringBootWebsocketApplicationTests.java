package com.formation.springbootwebsocket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebsocketApplicationTests {

    @Test
    void contextLoads() {
    }

}
